# No Free Lunch
## Removes free power and infinite resources. 

- The Portable Fusion Reactor requires burnable energy.
- The OffShore Pump is replaced with burner and electric varieties.
- The Spidertron requires burnable energy.
- Pumpjacks will eventually run dry.
- Open Water will eventually be depleted. 

