# No Free Lunch
## Removes source of free power

This mod aims to remove items from the game that provide energy without sunlight or fuel.

- The Portable Fusion Reactor required burnable energy.
- The OffShore Pump is replaced with burner and electric varieties.
